module Lab4 (
    input wire clk,       // 50 MHz clock
    output wire rf_out
);

    // 1 MHz RF carrier
    reg [4:0] rf_count = 0;
    reg carrier = 0;

    always @(posedge clk) begin
        if (rf_count == 24) begin
            rf_count <= 0;
            carrier <= ~carrier;
        end else begin
            rf_count <= rf_count + 1'b1;
        end
    end

    // Romanian hora-style melody
    // 32 steps, repeating continuously

    reg [4:0] note_index = 0;
    reg [16:0] tone_count = 0;
    reg [24:0] duration_count = 0;
    reg audio = 0;

    // Musical note half-periods for 50 MHz clock
    function [16:0] note_divisor;
        input [4:0] step;
        begin
            case (step)
                // D5 F5 A5 A5
                0, 7, 14, 18, 27, 29:
                    note_divisor = 17'd42610; // D5
                1, 10, 15, 22, 26, 28:
                    note_divisor = 17'd35816; // F5
                2, 3, 11, 20:
                    note_divisor = 17'd28409; // A5

                // G5 F5 E5 D5
                4, 23:
                    note_divisor = 17'd31887; // G5
                5, 9, 25:
                    note_divisor = 17'd35816; // F5
                6, 17, 24:
                    note_divisor = 17'd37936; // E5

                // Higher, festive notes
                8, 19, 21:
                    note_divisor = 17'd21276; // D6
                12:
                    note_divisor = 17'd23900; // C6
                13:
                    note_divisor = 17'd28409; // A5
                16:
                    note_divisor = 17'd42610; // D5
                30, 31:
                    note_divisor = 17'd42610; // D5

                default:
                    note_divisor = 17'd31887; // G5
            endcase
        end
    endfunction

    // Alternate short and long notes for a lively rhythm.
    // 150 ms = 7,500,000 clock cycles
    // 300 ms = 15,000,000 clock cycles
    function [24:0] note_duration;
        input [4:0] step;
        begin
            case (step)
                3, 7, 11, 15, 19, 23, 27, 31:
                    note_duration = 25'd14999999;
                default:
                    note_duration = 25'd7499999;
            endcase
        end
    endfunction

    always @(posedge clk) begin
        // Generate the current musical note
        if (tone_count >= note_divisor(note_index)) begin
            tone_count <= 0;
            audio <= ~audio;
        end else begin
            tone_count <= tone_count + 1'b1;
        end

        // Advance to the next note
        if (duration_count >= note_duration(note_index)) begin
            duration_count <= 0;
            tone_count <= 0;
            audio <= 0;

            if (note_index == 31)
                note_index <= 0;
            else
                note_index <= note_index + 1'b1;
        end else begin
            duration_count <= duration_count + 1'b1;
        end
    end

    // Original OOK modulation
    assign rf_out = carrier & audio;

endmodule