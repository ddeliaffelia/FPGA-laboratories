module Lab3(input clk, input key1, output reg [7:0] seg, output [3:0] dig, output led2);

reg [3:0] n = 0;
reg old = 1;

assign dig = 4'b1110; //one digit ON
reg led2_state = 0;

always @(posedge clk) begin
	old <= key1;
	if (old & ~key1) n <= (n==9) ? 0 : n+1;

	case (n)
		0: begin
				seg = 8'hC0;
				led2_state <= ~led2_state;
			end
		1: seg = 8'hF9;
		2: seg = 8'hA4; 3: seg = 8'hB0;
		4: seg = 8'h99; 5: seg = 8'h92;
		6: seg = 8'h82; 7: seg = 8'hF8;
		8: seg = 8'h80; 9: seg = 8'h90;

	endcase	
end

assign led2 = ~led2_state;

endmodule

// BLINK LED2 BASED ON THE CYCLE OF THE COUNTER
// WHEN U REACH 9 on THEN RESETS
// TILDA OPERATOR