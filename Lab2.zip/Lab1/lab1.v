module lab1 (
	input wire clk,
	input wire key1, 
	output wire led1,
	output wire led2,
	output wire led3,
	output wire led4
);

reg [25:0] counter = 0;
reg blink_enable = 0;
reg key_prev = 1;
reg led1_state = 0;
reg led2_state = 0;
reg led3_state = 0;
reg led4_state = 0;

always @(posedge clk) begin
	key_prev <= key1;
	
	if (key_prev == 1 && key1 == 0)
		blink_enable <= ~blink_enable;
		
	if(blink_enable) begin
		if (counter == 12_500_000) begin
			counter <= 0;
			led1_state <= ~led1_state;
			led2_state <= ~led2_state;
			led3_state <= ~led3_state;
			led4_state <= ~led4_state;
		end else begin
			counter <= counter + 1;
		end
	end else begin
		counter <= 0;
		led1_state <= 0;
		led2_state <= 0;
		led3_state <= 0;
		led4_state <= 0;
	end

end

assign led1 = ~led1_state;
assign led2 = ~led2_state;
assign led3 = ~led3_state;
assign led4 = ~led4_state;
	
endmodule